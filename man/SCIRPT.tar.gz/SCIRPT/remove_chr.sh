#!/bin/bash

ls chr*.fa | while read id; do \
  cat $id | awk '{if(NR==1){gsub(/chr/, "", $0);print}else{print $0}}' > "GATK_"${id}; \
done

cat GATK_chrM.fa GATK_chr1.fa GATK_chr2.fa GATK_chr3.fa GATK_chr4.fa GATK_chr5.fa GATK_chr6.fa GATK_chr7.fa GATK_chr8.fa \
  GATK_chr9.fa GATK_chr10.fa GATK_chr11.fa GATK_chr12.fa GATK_chr13.fa GATK_chr14.fa GATK_chr15.fa GATK_chr16.fa GATK_chr17.fa \
  GATK_chr18.fa GATK_chr19.fa GATK_chr20.fa GATK_chr21.fa GATK_chr22.fa GATK_chrX.fa GATK_chrY.fa > hg19.fa

rm GATK_*.fa