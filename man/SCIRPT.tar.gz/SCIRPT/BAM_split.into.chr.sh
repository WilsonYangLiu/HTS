#!/bin/bash

DIR=/WORK/sibs_lnchen_1/DATA/TEST/
BAM=KPGP-00001.uniAln.rmdup.bam
thread=22
TMP=${DIR}temp

cd $DIR
for chrom in `seq 1 22` X Y M; do 
samtools view -@ $thread -bh $BAM chr${chrom} | samtools sort -@ $thread -T $TMP -o chr${chrom}.bam -
samtools index chr${chrom}.bam
done

mkdir Split.into.chr && mv chr*.bam Split.into.chr