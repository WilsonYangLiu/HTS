#!/bin/bash

APP=/WORK/sibs_lnchen_1/SOFT

# install bwa
cd ${APP}/bwa-0.7.15
make
mkdir bin && mv bwa bin

# install samtools
cd ${APP}/samtools-1.4.1
mkdir exec
BIN=${APP}/samtools-1.4.1/exec/
./configure --enable-plugins --enable-libcurl --prefix=$BIN
make all all-htslib
make install install-htslib

# install bcftools
cd ${APP}/bcftools-1.4.1
mkdir exec
BIN=${APP}/bcftools-1.4.1/exec/
make prefix=$BIN install