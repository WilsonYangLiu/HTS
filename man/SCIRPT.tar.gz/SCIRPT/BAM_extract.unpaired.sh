#

DIR=/media/wilson/b776f228-366c-4e52-acd6-65df5b458e8c/Work_Genomes/test.KPGP
BAM=KPGP-00001_L1.sorted.bam

cd $DIR
samtools view -@ 2 -h $BAM | perl -alne '{print if $F[6] ne "="}' > unpaired.sam
#cut -f 3,7 unpaired.sam | sort | uniq -c > unpaired.counts
