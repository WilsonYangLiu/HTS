﻿from __future__ import print_function

#!/usr/local/bin/python
# -*- coding: utf-8 -*-

############################################################
#  Program: 
#  Version: 0.1.1
#  Author: Wei-Xin Liu (lweixin316@gmail.com)
############################################################

import os, sys
import re

def whiteSpaceRepl(matchobj):
	return ' '
	
def parse_conf(conf, *OpL, **OpD):
	'''	conf: configration file
	'''
	with open(conf, 'rb') as f:
		lines = [line.strip() for line in f if not line.startswith('#') ]
		lines = [line for line in lines if line != '']

	conf_Dict = {}
	for item in lines:
		if item.startswith('>'):
			prefix = item[1:]
			if prefix not in ['fq', 'bwa_mem', 'samtool_sort', 'samtool_merge', 'rmdup_uniAln', 'var_calling', 'vcf_filter']:
				print('''
[KEY ERROR] Currently only supported keys: fq, bwa_mem, samtool_sort, samtool_merge, rmdup_uniAln, var_calling, vcf_filter
---> {} found
'''.format(prefix))
				sys.exit(1)
			
		else:
			key, val = item.split('=')
			conf_Dict['_'.join([prefix, key] ) ] = val
			
	return(conf_Dict)

def fileList(f1, f2='', mode='PE'):
	'''	Assume file name format: sampleID_laneID_Ri.fq[.gz], here i can be 0 OR (1 2), 
		0 for SE, 1 and 2 for PE. 
			For SE, '_R0' can be omitted, meaning: sampleID_laneID.fq[.gz]
	'''
	if not ['PE', 'SE'].count(mode):
		flow_log.write('[File: Args Error] Please supply "PE"/"SE" to mode\n')
		print('[File: Args Error] Please supply "PE"/"SE" to mode')
		sys.exit(1)
		
	if mode == 'SE':
		flow_log.write('[File: Process] regards input reads as single-end\n\t', \
				'File list f2 will be omitted\n')
		print('[File: Process] regards input reads as single-end\n\t', \
				'File list f2 will be omitted')
		allFiles = dict()
		with open(f1, 'rb') as f:
			tmp = [line.strip() for line in f]
			allFiles['fastq_1_name'] = tmp
			#allFiles['fastq_2_name'] = [''] * len(tmp)
			tmp = [item.split('.')[0] for item in tmp]
			allFiles['Lane_name'] = tmp
			tmp = [item.split('_')[0] for item in tmp]
			allFiles['Sample_name'] = tmp
			
		return allFiles
		
	if mode == 'PE':
		if f2:
			PE1 = open(f1, 'rb')
			PE2 = open(f2, 'rb')
			
			allFiles = dict()
			tmp1 = [line.strip() for line in PE1]
			tmp2 = [line.strip() for line in PE2]
			allFiles['fastq_1_name'] = tmp1
			allFiles['fastq_2_name'] = tmp2
			tmp1 = [item.split('.')[0][:-3] for item in tmp1]
			tmp2 = [item.split('.')[0][:-3] for item in tmp2]
			if tmp1 == tmp2:
				allFiles['Lane_name'] = tmp1
			else:
				flow_log.write('[File: Order Error] your 2 files f1, f2 are not in same order\n')
				print('[File: Order Error] your 2 files f1, f2 are not in same order')
				sys.exit(1)
			tmp = [item.split('_')[0] for item in tmp1]
			allFiles['Sample_name'] = tmp
				
			PE1.close()
			PE2.close()
			
			return allFiles
		
		else:
			flow_log.write('[File: Args] f2 missing, assumes the 2i-th and the (2i+1)-th file in f1 constitute a read pair\n')
			print('[File: Args] f2 missing, assumes the 2i-th and the (2i+1)-th file in f1 constitute a read pair')
			allFiles = dict()
			with open(f1, 'rb') as f:
				tmp = [line.strip() for line in f]
				if len(tmp) % 2:
					flow_log.write('[File: Error] either your files are SE, or your files are missing\n')
					print('[File: Error] either your files are SE, or your files are missing')
					sys.exit(1)
				else:
					tmp1 = [tmp[i] for i in range(len(tmp) ) if not (i % 2)]
					tmp2 = [tmp[i] for i in range(len(tmp) ) if (i % 2)]
					allFiles['fastq_1_name'] = tmp1
					allFiles['fastq_2_name'] = tmp2
					tmp1 = [item.split('.')[0][:-3] for item in tmp1]
					tmp2 = [item.split('.')[0][:-3] for item in tmp2]
					if tmp1 == tmp2:
						allFiles['Lane_name'] = tmp1
					else:
						flow_log.write('[File: Order Error] order of file in f1 are chaotic\n')
						print('[File: Order Error] order of file in f1 are chaotic')
						sys.exit(1)
					tmp = [item.split('_')[0] for item in tmp1]
					allFiles['Sample_name'] = tmp
					
			return allFiles

def infer_RG(fastq):
	'''	fastq: str. the name of fastq format file
	'''
	ID = fastq.split('.', 1)[0]
	SM = ':'.join(['SM', ID.split('_', 1)[0] ] )
	LB = ':'.join(['LB', ID.split('_')[1] ] )
	ID = ':'.join(['ID', '_'.join(ID.split('_')[:2] ) ] )
	
	return '\\t'.join(['@RG', ID, SM, LB])
			
def bwa_mem(DB_prefix, R1, R2 = '', \
			outSAM = 'out.sam', \
			LOG = 'out.bwa.align.log', \
			M = True, t = 4, \
			R = '@RG\\tID:foo\\tSM:bar\\tLB:library1', \
			**OpD):
	'''	DB_prefix: reference fasta file (indexed with bwa).
		R1: paired-end fastq file. if -p flag (bwa mem) is used then expected to be
			an interleaved paired-end fastq file, and in2.fq will be omitted.
		R2: paired-end fastq file.
		outSAM: the output alignment file, SAM format.
		LOG: log file
		M: boolean. Mark shorter split hits as secondary (for Picard compatibility).
		t: threads [4]
		R: read group header line ['@RG\tID:foo\tSM:bar\tLB:library1']
		OpD: other bwa mem options
	'''
	
	if (not R2) and (not OpD.has_key('p') ):
		flow_log.write('[BWA: Process] regards input reads as single-end\n' )
		print('[BWA: Process] regards input reads as single-end' )
		
	if OpD.has_key('p'):
		flow_log.write('[BWA: Args] -p flag exist:\n'
				'\tFirst fastq (R1) file consists of interleaved paired-end sequences,\n',\
				'\tSecond fastq (R2) file will be omitted\n')
		print('[BWA: Args] -p flag exist:\n'
				'\tFirst fastq (R1) file consists of interleaved paired-end sequences,\n',\
				'\tSecond fastq (R2) file will be omitted')
	
	if not R.startswith('@'):
		flow_log.write('[BWA: Option Format Error]', '-R option must start with "@"\n\t', \
		'For example: \'@RG\\tID:foo\\tSM:bar\\tLB:library1\'\n')
		print('[BWA: Option Format Error]', '-R option must start with "@"\n\t', \
		'For example: \'@RG\\tID:foo\\tSM:bar\\tLB:library1\'')
		sys.exit(1)
	
	Op = ''
	if OpD:
		for key in OpD.keys():
			OpTmp = ''.join(['-', key, ' ', str(OpD[key]) ] )
			Op = ' '.join([OpTmp, Op] )
		
	cmd = ' '.join(['bwa mem', \
		'-M' if M else '', \
		' '.join(['-t', str(t) ] ), \
		''.join(['-R \'', R, '\''] ), \
		Op[:-1], \
		DB_prefix, R1, R2, \
		' '.join(['1>', outSAM]), \
		' '.join(['2>', LOG] ) ] )
	cmd = re.sub('[ ]{2,}', whiteSpaceRepl, cmd)
	task.write(''.join([cmd, '\n']))
	print(cmd)
	#os.system(cmd)
		
def samtool_sort(lane_name, t = 4, n = False, **OpD):
	'''	Sort the BAM by coordinate or by name, then we index the BAM file
	
		lane_name: the unique and unsorted SAM/BAM file name
		t: number of thread
		n: boolean, sort by name or not
		OpD: other samtools sort/index options
	'''
	lane_name_alt = lane_name.split('.', 1)[0]
	baseName = lane_name.split('.', 1)[1]
	if baseName.endswith('sam'):
		baseName = baseName.replace('sam', 'bam')
		
	if not os.path.isdir('temp'):
		os.mkdir('temp')

	Op = ''
	if OpD:
		for key in OpD.keys():
			OpTmp = ''.join(['-', key, ' ', str(OpD[key]) ] )
			Op = ' '.join([OpTmp, Op] )

	# Sort
	cmd_sort = ' '.join(['samtools sort', \
			'-n' if n else '', \
			' '.join(['-@', str(t) ] ), \
			''.join(['-o ', lane_name_alt, '.sorted.', baseName] ), \
			''.join(['-T ', 'temp'] ), \
			Op[:-1], \
			lane_name ] )
	cmd_sort = re.sub('[ ]{2,}', whiteSpaceRepl, cmd_sort)
	task.write(''.join([cmd_sort, '\n']))
	print(cmd_sort)
	#os.system(cmd_sort)
	
	# index
	cmd_index = ' '.join(['samtools index', \
				''.join([lane_name_alt, '.sorted.', baseName] ) ] )
	cmd_index = re.sub('[ ]{2,}', whiteSpaceRepl, cmd_index)
	task.write(''.join([cmd_index, '\n']))
	print(cmd_index)
	#os.system(cmd_index)

def samtool_merge(lane_list, t = 4, f = True, n = False, **OpD):
	'''	lane_list: the list of seperated file to be merged
		t: number of thread
		f：boolean. overwrite the output BAM if exist
		n: boolean. the in.BAM (in lane_list) are sorted by name or not
		OpD: other samtools sort/index options
	'''
	sampleID = [lane.split('_', 1)[0] for lane in lane_list]
	if len(set(sampleID) ) != 1:
		flow_log.write('[Sample Error] you supply more than one sample, please check again\n')
		print('[Sample Error] you supply more than one sample, please check again')
		sys.exit(1)
		
	sampleID = sampleID[0]
	
	if OpD.has_key('b'):
		flow_log.write('[Arg omitted] this is a removed argument, do not use it\n\t', \
				'supply a list of in_i.bam to this function')
		print('[Arg omitted] this is a removed argument, do not use it\n\t', \
				'supply a list of in_i.bam to this function')
		OpD.pop('b')
		
	Op = ''
	if OpD:
		for key in OpD.keys():
			OpTmp = ''.join(['-', key, ' ', str(OpD[key]) ] )
			Op = ' '.join([OpTmp, Op] )
	
	lane_list = ' '.join(lane_list)
	
	cmd = ' '.join(['samtools merge', \
		'-f' if f else '', \
		' '.join(['-@', str(t) ] ), \
		'-n' if n else '', \
		Op[:-1], \
		''.join([sampleID, '.merge.bam'] ), \
		lane_list] )
	cmd = re.sub('[ ]{2,}', whiteSpaceRepl, cmd)
	task.write(''.join([cmd, '\n']))
	print(cmd)
	#os.system(cmd)
	
def rmdup_uniAln(bam, t = 4, picard='picard.jar', uniqueAln=True, **OpD):
	'''	bam: the final merged (sorted) BAM file name
		t: number of thread
		picard: the path of picard.jar
		uniqueAln: Remove multi-mapped reads
		OpD: other samtools sort/index options
	'''
	#if not os.path.isfile(picard):
	if os.path.isfile(picard):
		flow_log.write('[picard.jar Error] Please specified the right path of picard.jar\n')
		print('[picard.jar Error] Please specified the right path of picard.jar')
		sys.exit(1)
		
	if not os.path.isdir('temp'):
		os.mkdir('temp')
		
	Op = ''
	if OpD:
		for key in OpD.keys():
			OpTmp = ''.join([key, '=', str(OpD[key]) ] )
			Op = ' '.join([OpTmp, Op] )
			
	cmd = ' '.join(['java -Xmx2g -jar', \
					picard, \
					'MarkDuplicates', \
					'VALIDATION_STRINGENCY=LENIENT', \
					'='.join(['CREATE_INDEX', 'false' if uniqueAln else 'true']), \
					'TMP_DIR=temp', \
					'TAGGING_POLICY=All', \
					'REMOVE_DUPLICATES=true', \
					Op[:-1], \
					'='.join(['INPUT', bam]), \
					''.join(['OUTPUT=', bam.split('.', 1)[0], '.rmdup.bam']), \
					''.join(['METRICS_FILE=', bam.split('.', 1)[0], '.picard.metrics']), \
					''.join(['2> ', bam.split('.', 1)[0], '.picard.log']) ] )
	cmd = re.sub('[ ]{2,}', whiteSpaceRepl, cmd)
	task.write(''.join([cmd, '\n']))
	print(cmd)
	#os.system(cmd)
	
	if uniqueAln:
		bam = ''.join([bam.split('.', 1)[0], '.rmdup.bam'])
		cmd_sort = ' '.join(['samtools view -q 1 -h', \
							bam, \
							'| samtools sort', \
							' '.join(['-@', str(t) ] ), \
							''.join(['-o ', bam.split('.', 1)[0], '.uniAln.', bam.split('.', 1)[1]]) ])
		cmd_sort = re.sub('[ ]{2,}', whiteSpaceRepl, cmd_sort)
		task.write(''.join([cmd_sort, '\n']))
		print(cmd_sort)	
		#os.system(cmd_sort)
		
		cmd_index = ' '.join(['samtools index', \
							''.join([bam.split('.', 1)[0], '.uniAln.', bam.split('.', 1)[1]]) ])
		cmd_index = re.sub('[ ]{2,}', whiteSpaceRepl, cmd_index)
		task.write(''.join([cmd_index, '\n']))
		print(cmd_index)
		#os.system(cmd_index)
		
def var_calling(bam, t = 1, reference = 'hg19.fa', **OpD):
	'''	bam: the bam file with duplicate and multi-mapped read removed
		t: number of thread
		reference: reference fasta file (index)
		OpD: other samtools sort/index options
	'''
	if not os.path.isfile(reference):
		flow_log.write('[reference Error] Please specified the right path of reference')
		print('[reference Error] Please specified the right path of reference')
		sys.exit(1)
	
	vcf = '.'.join([bam.split('.', 1)[0], 'vcf.gz'])
	
	Op = ''
	if OpD:
		for key in OpD.keys():
			OpTmp = ''.join(['-', key, ' ', str(OpD[key]) ] )
			Op = ' '.join([OpTmp, Op] )
			
	cmd = ' '.join(['samtools mpileup -ugf', \
					reference, \
					bam, \
					'| bcftools call', \
					' '.join(['--threads', str(t)] ), \
					'-vmO z', 
					Op[:-1], \
					' '.join(['-o', vcf]) ] )
	cmd = re.sub('[ ]{2,}', whiteSpaceRepl, cmd)
	task.write(''.join([cmd, '\n']))
	print(cmd)
	#os.system(cmd)
	
	cmd_tbi = ' '.join(['tabix -p vcf', vcf])
	task.write(''.join([cmd_tbi, '\n']))
	print(cmd_tbi)
	#os.system(cmd_tbi)

def vcf_filter(vcf, s = 'LOWQUAL', i = '\'%QUAL>10\'', **OpD):
	'''	vcf: the vcf format file
		s: soft-flter, annotate FILTER column with s
		i: include, include only site for which i is true
		OpD: other samtools sort/index options
	'''
	vcf_flt = vcf.split('.', 1)
	vcf_flt = '.'.join([vcf_flt[0], 'flt', vcf_flt[1] ] )
	
	Op = ''
	if OpD:
		for key in OpD.keys():
			OpTmp = ''.join(['-', key, ' ', str(OpD[key]) ] )
			Op = ' '.join([OpTmp, Op] )
			
	cmd = ' '.join(['bcftools filter -O z', \
					' '.join(['-s', str(s) ] ), \
					' '.join(['-i', str(i) ] ), \
					' '.join(['-o', vcf_flt]), \
					vcf] )
	cmd = re.sub('[ ]{2,}', whiteSpaceRepl, cmd)
	task.write(''.join([cmd, '\n']))
	print(cmd)
	#os.system(cmd)
	
def work_flow(Work_DIR, conf_Dict):
	'''	Work_DIR: wording directory
		conf_Dict: user defined options
	'''
	os.chdir(Work_DIR)
	
	fileInfo = fileList(f1 = conf_Dict['fq_file_list_1'], f2 = conf_Dict['fq_file_list_2'] )
	if len(set(fileInfo['Lane_name'] ) ) != len(fileInfo['Lane_name']):
		flow_log.write('[File Name Error] Sample_Lane name must be unique\n')
		print('[File Name Error] Sample_Lane name must be unique')
		sys.exit(1)
		
	# bwa mem
	bwa_mem_keys = [key for key in conf_Dict.keys() if key.startswith('bwa_mem')]
	bwa_mem_OpD = {key:conf_Dict[key] for key in bwa_mem_keys}
	for key in ['bwa_mem_M', 'bwa_mem_ref', 'bwa_mem_t', 'bwa_mem_R']:
		bwa_mem_OpD.pop(key)
	for sample in set(fileInfo['Sample_name']):
		laneInfo = [lane for lane in fileInfo['Lane_name'] if lane.startswith(sample) ]
		for lane in laneInfo:
			bwa_mem(DB_prefix = conf_Dict['bwa_mem_ref'], \
					R1 = [item for item in fileInfo['fastq_1_name'] if item.startswith(lane) ][0], \
					R2 = [item for item in fileInfo['fastq_2_name'] if item.startswith(lane) ][0] if fileInfo.has_key('fastq_2_name') else '', \
					outSAM = ''.join([lane, '.sam']), \
					LOG = ''.join([lane, '.bwa.align.log']), \
					M = conf_Dict['bwa_mem_M'], \
					t = conf_Dict['bwa_mem_t'], \
					R = infer_RG([item for item in fileInfo['fastq_1_name'] if item.startswith(lane) ][0] ) if not conf_Dict['bwa_mem_R'] else conf_Dict['bwa_mem_R'], \
					**bwa_mem_OpD)
					
	if not os.path.isdir('FASTQ'):
		task.write('mkdir FASTQ && ')
		print('mkdir FASTQ')
		os.mkdir('FASTQ')
	cmd = ' '.join(['mv', \
					'* '.join(fileInfo['fastq_1_name']) + '*', \
					'* '.join(fileInfo['fastq_2_name']) + '*', \
					'FASTQ/'])
	task.write(''.join([cmd, '\n']))
	print(cmd)
	#os.system(cmd)
	
	fileInfo['SAM'] = ['.'.join([lane, 'sam'] ) for lane in fileInfo['Lane_name'] ]
	
	# samtool sort/index
	samtool_sort_keys = [key for key in conf_Dict.keys() if key.startswith('samtool_sort')]
	samtool_sort_OpD = {key:conf_Dict[key] for key in samtool_sort_keys}
	for key in ['samtool_sort_t', 'samtool_sort_n']:
		samtool_sort_OpD.pop(key)
	for sample in set(fileInfo['Sample_name']):
		samInfo = [sam for sam in fileInfo['SAM'] if sam.startswith(sample) ]
		for sam in samInfo:
			samtool_sort(sam, \
						t = conf_Dict['samtool_sort_t'], \
						n = (conf_Dict['samtool_sort_n'] == 'True'), \
						**samtool_sort_OpD)
	
	if not os.path.isdir('SAM'):
		task.write('mkdir SAM && ')
		print('mkdir SAM')
		os.mkdir('SAM')
	cmd = ' '.join(['mv', \
					' '.join(fileInfo['SAM']), \
					'SAM/'])
	task.write(''.join([cmd, '\n']))
	print(cmd)
	#os.system(cmd)
	
	fileInfo['SORTED.BAM'] = ['.'.join([lane, 'sorted.bam'] ) for lane in fileInfo['Lane_name'] ]

	# samtool merge
	samtool_merge_keys = [key for key in conf_Dict.keys() if key.startswith('samtool_merge')]
	samtool_merge_OpD = {key:conf_Dict[key] for key in samtool_merge_keys}
	for key in ['samtool_merge_f', 'samtool_merge_n', 'samtool_merge_t']:
		samtool_merge_OpD.pop(key)
	for sample in set(fileInfo['Sample_name']):
		sortedBamList = [bam for bam in fileInfo['SORTED.BAM'] if bam.startswith(sample) ]
		if len(sortedBamList) > 1:
			samtool_merge(sortedBamList, \
						t = conf_Dict['samtool_merge_t'], \
						f = conf_Dict['samtool_merge_f'], \
						n = (conf_Dict['samtool_merge_n'] == 'True'), \
						**samtool_merge_OpD)
						
			if not os.path.isdir('BAM'):
				task.write('mkdir BAM && ')
				print('mkdir BAM')
				os.mkdir('BAM')
			cmd = ' '.join(['mv', \
							' '.join(sortedBamList), \
							'BAM/'])
			task.write(''.join([cmd, '\n']))
			print(cmd)
			#os.system(cmd)
		elif len(sortedBamList) == 1:
			sortedBam = sortedBamList.pop()
			cmd = ' '.join(['mv', \
							sortedBam, \
							'.'.join([sample, 'merge.bam'])])
			task.write(''.join([cmd, '\n']))
			print(cmd)
			#os.system(cmd)
			
			cmd = ' '.join(['mv', \
							'.'.join([sortedBam, 'bai']), \
							'.'.join([sample, 'merge.bam.bai'])])
			task.write(''.join([cmd, '\n']))
			print(cmd)
			#os.system(cmd)
					
	fileInfo['MERGE.BAM'] = ['.'.join([sample, 'merge.bam'] ) for sample in fileInfo['Sample_name'] ]
	
	# samtool_sort/index for merge BAM file
	for sample in set(fileInfo['Sample_name']):
		sortedBamList = [bam for bam in fileInfo['SORTED.BAM'] if bam.startswith(sample) ]
		mergeBamList = set([bam for bam in fileInfo['MERGE.BAM'] if bam.startswith(sample) ])
		if len(mergeBamList) == 1:
			mergeBAM = mergeBamList.pop()
			if len(sortedBamList) > 1:
				samtool_sort(mergeBAM, \
							t = conf_Dict['samtool_sort_t'], \
							n = conf_Dict['samtool_sort_n'], \
							**samtool_sort_OpD)
				
				cmd = ' '.join(['mv', \
								mergeBAM, \
								'BAM/'])
				task.write(''.join([cmd, '\n']))
				print(cmd)
				#os.system(cmd)
			elif len(sortedBamList) == 1:
				cmd = ' '.join(['mv', \
								mergeBAM, \
								'.'.join([sample, 'sorted.merge.bam'])])
				task.write(''.join([cmd, '\n']))
				print(cmd)
				#os.system(cmd)
				
				cmd = ' '.join(['mv', \
								'.'.join([mergeBAM, 'bai']), \
								'.'.join([sample, 'sorted.merge.bam.bai'])])
				task.write(''.join([cmd, '\n']))
				print(cmd)
				#os.system(cmd)
			
		else:
			flow_log.write('[Sample Error] One sample should only have one merge.bam file\n')
			print('[Sample Error] One sample should only have one merge.bam file')
			sys.exit(1)
			
	fileInfo['SORTED.MERGE.BAM'] = ['.'.join([sample, 'sorted.merge.bam'] ) for sample in fileInfo['Sample_name'] ]
		
	# remove duplication and multi-mapped reads
	rmdup_uniAln_keys = [key for key in conf_Dict.keys() if key.startswith('rmdup_uniAln')]
	rmdup_uniAln_OpD = {key:conf_Dict[key] for key in rmdup_uniAln_keys}
	for key in ['rmdup_uniAln_picard', 'rmdup_uniAln_uniqueAln', 'rmdup_uniAln_t']:
		rmdup_uniAln_OpD.pop(key)
	for sample in set(fileInfo['Sample_name']):
		bamList = set([bam for bam in fileInfo['SORTED.MERGE.BAM'] if bam.startswith(sample) ] )
		if len(bamList) == 1:
			bam = bamList.pop()
			rmdup_uniAln(bam, \
						t = conf_Dict['rmdup_uniAln_t'], \
						picard = conf_Dict['rmdup_uniAln_picard'], \
						uniqueAln = conf_Dict['rmdup_uniAln_uniqueAln'], \
						**rmdup_uniAln_OpD)
		else:
			flow_log.write('[Sample Error] One sample should only have one sorted.merge.bam file\n')
			print('[Sample Error] One sample should only have one sorted.merge.bam file')
			sys.exit(1)
			
	fileInfo['rmDup.BAM'] = ['.'.join([sample, 'uniAln.rmdup.bam' if conf_Dict['rmdup_uniAln_uniqueAln'] else 'rmdup.bam']) for sample in fileInfo['Sample_name'] ]
	
	# variance calling and filter
	var_calling_keys = [key for key in conf_Dict.keys() if key.startswith('var_calling')]
	var_calling_OpD = {key:conf_Dict[key] for key in var_calling_keys}
	for key in ['var_calling_ref', 'var_calling_t']:
		var_calling_OpD.pop(key)
	
	vcf_filter_keys = [key for key in conf_Dict.keys() if key.startswith('vcf_filter')]
	vcf_filter_OpD = {key:conf_Dict[key] for key in vcf_filter_keys}
	for key in ['vcf_filter_i', 'vcf_filter_s']:
		vcf_filter_OpD.pop(key)
	for sample in set(fileInfo['Sample_name']):
		bamList = set([bam for bam in fileInfo['rmDup.BAM'] if bam.startswith(sample) ] )
		if len(bamList) == 1:
			bam = bamList.pop()
			var_calling(bam, \
						t = conf_Dict['var_calling_t'], \
						reference = conf_Dict['var_calling_ref'], \
						**var_calling_OpD)
						
			vcf = '.'.join([bam.split('.', 1)[0], 'vcf.gz'])
			vcf_filter(vcf, \
						s = conf_Dict['vcf_filter_s'], \
						i = conf_Dict['vcf_filter_i'], \
						**vcf_filter_OpD)
		else: 
			flow_log.write('[Sample Error] One sample should only have one [uniAln.]rmdup.bam file\n')
			print('[Sample Error] One sample should only have one [uniAln.]rmdup.bam file')
			sys.exit(1)
	
	fileInfo['VCF'] = ['.'.join([sample, 'flt.vcf.gz'] ) for sample in fileInfo['Sample_name'] ]
	
	return(fileInfo)
	
if __name__ == '__main__':
	#os.chdir(r'/WORK/sibs_lnchen_1/DATA/TEST/')
	#os.chdir(r'E:\Work_Genomes\test.KPGP')
	#os.chdir(r'/media/wilson/b776f228-366c-4e52-acd6-65df5b458e8c/Work_Genomes/test.KPGP')
	os.chdir(r'E:/Work_Genomes/test.tmp')
	

	task = open('task.sh', 'wb')
	task.write('#!/bin/bash\n\n')
	
	flow_log = open('work_flow.log', 'wb')
	
	conf_Dict = parse_conf(conf = r'./tmp.conf')
	fileInfo = work_flow(Work_DIR = './', conf_Dict = conf_Dict)
	
	task.close()
	flow_log.close()
	
'''
	fileInfo = fileList(f1 = 'fileList.txt' )
	if len(set(fileInfo['Lane_name'] ) ) != len(fileInfo['Lane_name']):
		print('[File Name Error] Lane name must be unique')
		sys.exit(1)
		
	# bwa mem
	bwa_mem_ref = r'../index/bwa/hg19'
	bwa_mem_M = True
	bwa_mem_t = 24
	bwa_mem_R = '@RG\\tID:KPGP-00001\\tSM:KPGP-00001\\tLB:lib1'	# this can be infer from the filename, LATER
	bwa_mem_OpD = {}
	for sample in set(fileInfo['Sample_name']):
		laneInfo = [lane for lane in fileInfo['Lane_name'] if lane.startswith(sample) ]
		for lane in laneInfo:
			bwa_mem(DB_prefix = bwa_mem_ref, \
					R1 = [item for item in fileInfo['fastq_1_name'] if item.startswith(lane) ][0], \
					R2 = [item for item in fileInfo['fastq_2_name'] if item.startswith(lane) ][0] if fileInfo.has_key('fastq_2_name') else '', \
					outSAM = ''.join([lane, '.sam']), \
					LOG = ''.join([lane, '.bwa.align.log']), \
					M = bwa_mem_M, \
					t = bwa_mem_t, \
					R = infer_RG([item for item in fileInfo['fastq_1_name'] if item.startswith(lane) ][0] ) if not bwa_mem_R else bwa_mem_R, \
					**bwa_mem_OpD)
					
	if not os.path.isdir('FASTQ'):
		os.mkdir('FASTQ')
	cmd = ' '.join(['mv', \
					'* '.join(fileInfo['fastq_1_name']) + '*', \
					'* '.join(fileInfo['fastq_2_name']) + '*', \
					'FASTQ/'])
	#os.system(cmd)
	print(cmd)
	fileInfo['SAM'] = ['.'.join([lane, 'sam'] ) for lane in fileInfo['Lane_name'] ]
	
	# samtool sort/index
	samtool_sort_t = 24
	samtool_sort_n = False
	samtool_sort_OpD = {}
	for sample in set(fileInfo['Sample_name']):
		samInfo = [sam for sam in fileInfo['SAM'] if sam.startswith(sample) ]
		for sam in samInfo:
			samtool_sort(sam, \
						t = samtool_sort_t, \
						n = samtool_sort_n, \
						**samtool_sort_OpD)
	
	if not os.path.isdir('SAM'):
		os.mkdir('SAM')
	cmd = ' '.join(['mv', \
					' '.join(fileInfo['SAM']), \
					'SAM/'])
	#os.system(cmd)
	print(cmd)
	fileInfo['SORTED.BAM'] = ['.'.join([lane, 'sorted.bam'] ) for lane in fileInfo['Lane_name'] ]

	# samtool merge
	samtool_merge_t = 24
	samtool_merge_f = True
	samtool_merge_n = False
	samtool_merge_OpD = {}
	for sample in set(fileInfo['Sample_name']):
		sortedBamList = [bam for bam in fileInfo['SORTED.BAM'] if bam.startswith(sample) ]
		if len(sortedBamList) > 1:
			samtool_merge(sortedBamList, \
						t = samtool_merge_t, \
						f = samtool_merge_f, \
						n = samtool_merge_n, \
						**samtool_merge_OpD)
						
			if not os.path.isdir('BAM'):
				os.mkdir('BAM')
			cmd = ' '.join(['mv', \
							' '.join(sortedBamList), \
							'BAM/'])
			#os.system(cmd)
			print(cmd)
		elif len(sortedBamList) == 1:
			sortedBam = sortedBamList.pop()
			cmd = ' '.join(['mv', \
							sortedBam, \
							'.'.join([sample, 'merge.bam'])])
			#os.system(cmd)
			print(cmd)
			
			cmd = ' '.join(['mv', \
							'.'.join([sortedBam, 'bai']), \
							'.'.join([sample, 'merge.bam.bai'])])
			#os.system(cmd)
			print(cmd)
					
	fileInfo['MERGE.BAM'] = ['.'.join([sample, 'merge.bam'] ) for sample in fileInfo['Sample_name'] ]
	
	# samtool_sort/index for merge BAM file
	samtool_sort_t = 24
	samtool_sort_n = False
	samtool_sort_OpD = {}
	for sample in set(fileInfo['Sample_name']):
		sortedBamList = [bam for bam in fileInfo['SORTED.BAM'] if bam.startswith(sample) ]
		mergeBamList = set([bam for bam in fileInfo['MERGE.BAM'] if bam.startswith(sample) ])
		if len(mergeBamList) == 1:
			mergeBAM = mergeBamList.pop()
			if len(sortedBamList) > 1:
				samtool_sort(mergeBAM, \
							t = samtool_sort_t, \
							n = samtool_sort_n, \
							**samtool_sort_OpD)
				
				cmd = ' '.join(['mv', \
								mergeBAM, \
								'BAM/'])
				#os.system(cmd)
				print(cmd)
			elif len(sortedBamList) == 1:
				cmd = ' '.join(['mv', \
								mergeBAM, \
								'.'.join([sample, 'sorted.merge.bam'])])
				#os.system(cmd)
				print(cmd)
				
				cmd = ' '.join(['mv', \
								'.'.join([mergeBAM, 'bai']), \
								'.'.join([sample, 'sorted.merge.bam.bai'])])
				#os.system(cmd)
				print(cmd)
			
		else:
			print('[Sample Error] One sample should only have one merge.bam file')
			sys.exit(1)
			
	fileInfo['SORTED.MERGE.BAM'] = ['.'.join([sample, 'sorted.merge.bam'] ) for sample in fileInfo['Sample_name'] ]
		
	# remove duplication and multi-mapped reads
	rmdup_uniAln_t = 24
	rmdup_uniAln_picard='/WORK/sibs_lnchen_1/SOFT/picard-2.9.2/picard.jar'
	rmdup_uniAln_uniqueAln=True
	rmdup_uniAln_OpD = {}
	for sample in set(fileInfo['Sample_name']):
		bamList = set([bam for bam in fileInfo['SORTED.MERGE.BAM'] if bam.startswith(sample) ] )
		if len(bamList) == 1:
			bam = bamList.pop()
			rmdup_uniAln(bam, \
						t = rmdup_uniAln_t, \
						picard = rmdup_uniAln_picard, \
						uniqueAln = rmdup_uniAln_uniqueAln, \
						**rmdup_uniAln_OpD)
		else:
			print('[Sample Error] One sample should only have one sorted.merge.bam file')
			sys.exit(1)
			
	fileInfo['rmDup.BAM'] = ['.'.join([sample, 'uniAln.rmdup.bam' if rmdup_uniAln_uniqueAln else 'rmdup.bam']) for sample in fileInfo['Sample_name'] ]
	
	# variance calling and filter
	var_calling_t = 1
	var_calling_ref = '../genome/hg19/hg19.fa'
	var_calling_OpD = {}
	vcf_filter_OpD = {}
	for sample in set(fileInfo['Sample_name']):
		bamList = set([bam for bam in fileInfo['rmDup.BAM'] if bam.startswith(sample) ] )
		if len(bamList) == 1:
			bam = bamList.pop()
			var_calling(bam, \
						t = var_calling_t, \
						reference = var_calling_ref, \
						**var_OpD)
						
			vcf = '.'.join([bam.split('.', 1)[0], 'vcf.gz'])
			vcf_filter(vcf, \
						s = 'LOWQUAL', \
						i = '\'%QUAL>10\'', \
						**vcf_OpD)
		else: 
			print('[Sample Error] One sample should only have one [uniAln.]rmdup.bam file')
			sys.exit(1)
	
	fileInfo['VCF'] = ['.'.join([sample, 'flt.vcf.gz'] ) for sample in fileInfo['Sample_name'] ]
'''
	
