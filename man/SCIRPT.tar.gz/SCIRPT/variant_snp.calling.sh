#!/bin/bash

DIR=/WORK/sibs_lnchen_1/DATA/TEST/Split.into.chr/
reference=/WORK/sibs_lnchen_1/DATA/genome/hg19/hg19.fa
BAM=KPGP-00001.uniAln.rmdup.bam
thread=1

cd $DIR
:<<BLOCK
# Run variant calling of chromsome one by one
for chrom in `seq 1 22` X Y M; do
samtools mpileup -ugf $reference chr${chrom}.bam | \
bcftools call --threads $thread -vmO z -o `echo chr${chrom}.bam | awk 'BEGIN{FS=".";OFS="."}{print $1".vcf.gz"}'` &
done
BLOCK

# Run variant calling of whole genome
cd ../
samtools mpileup -ugf $reference $BAM | \
bcftools call --threads $thread -vmO z -o `echo $BAM | awk 'BEGIN{FS=".";OFS="."}{print $1".vcf.gz"}'`

vcf=`echo $BAM | awk 'BEGIN{FS=".";OFS="."}{print $1".vcf.gz"}'`
tabix -p vcf $vcf
bcftools stats -F $reference -s - $vcf > ${vcf}.stats
mkdir ${vcf}_stats && plot-vcfstats -p ${vcf}_stats/ ${vcf}.stats

bcftools filter -O z -o `echo $BAM | awk 'BEGIN{FS=".";OFS="."}{print $1".flt.vcf.gz"}'` -s LOWQUAL -i'%QUAL>10' $vcf 
