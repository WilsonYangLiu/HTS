#
DIR=/media/wilson/b776f228-366c-4e52-acd6-65df5b458e8c/Work_Genomes/test.tmp
ANNOVAR_DIR=/media/wilson/b776f228-366c-4e52-acd6-65df5b458e8c/Work_Genomes/app/annovar
vcf=KPGP-00001.flt.vcf.gz
annovar=`echo $vcf | awk 'BEGIN{FS=".";OFS="."}{print $1,"annovar"}'`

cd $DIR
convert2annovar.pl -format vcf4old $vcf > $annovar

annotate_variation.pl --geneanno --buildver hg19 $annovar ${ANNOVAR_DIR}/humandb-1/

annotate_variation.pl --regionanno --dbtype cytoBand --buildver hg19 $annovar ${ANNOVAR_DIR}/humandb-1/ 

annotate_variation.pl --filter --dbtype 1000g2015aug_all -buildver hg19 $annovar ${ANNOVAR_DIR}/humandb-1/ 

# Summary
cat ${annovar}.exonic_variant_function | awk -F "\t" '{print $2}' | sort | uniq -c > `echo $vcf | awk 'BEGIN{FS=".";OFS="."}{print $1,"exonic_summary"}'`

