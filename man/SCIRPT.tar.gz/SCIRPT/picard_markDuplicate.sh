#!/bin/bash

DIR=/WORK/sibs_lnchen_1/DATA/TEST/
picard=WORK/sibs_lnchen_1/SOFT/picard-2.9.2/picard.jar
BAM=KPGP-00001.sorted.merge.bam
thread=24

cd $DIR
# Remove Duplicate reads
:<<BLOCK
BLOCK
java -Xmx2g -jar $picard MarkDuplicates \
   VALIDATION_STRINGENCY=LENIENT \
   CREATE_INDEX=false \
   TMP_DIR=${DIR}temp \
   TAGGING_POLICY=All \
   REMOVE_DUPLICATES=true \
   INPUT=$BAM \
   OUTPUT=`echo ${BAM} | awk 'BEGIN{FS=".";OFS="."}{print $1".rmdup.bam"}'` \
   METRICS_FILE=`echo ${BAM} | awk 'BEGIN{FS=".";OFS="."}{print $1".metrics.txt"}'` \
   2> `echo ${BAM} | awk 'BEGIN{FS=".";OFS="."}{print $1".picard.log"}'`


# Remove multi-mapped reads
BAM=`echo ${BAM} | awk 'BEGIN{FS=".";OFS="."}{print $1".rmdup.bam"}'`
samtools view -q 1 -h $BAM | samtools sort -@ $thread -o `echo ${BAM} | awk 'BEGIN{FS=".";OFS="."}{print $1".uniAln",$2,$3}'` -
samtools index `echo ${BAM} | awk 'BEGIN{FS=".";OFS="."}{print $1".uniAln.",$2,$3}'`