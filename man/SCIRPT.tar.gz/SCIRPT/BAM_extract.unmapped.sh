#

DIR=/media/wilson/b776f228-366c-4e52-acd6-65df5b458e8c/Work_Genomes/test.KPGP
BAM=KPGP-00001_L1.sorted.bam

cd $DIR
samtools view -@ 2 -bf 4 $BAM > unmapped.bam
#samtools view unmapped.bam | cut -f 3,7 | sort | uniq -c > unmapped.counts
