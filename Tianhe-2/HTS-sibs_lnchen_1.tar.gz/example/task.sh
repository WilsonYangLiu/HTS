#!/bin/bash

bwa mem -M -t 24 -R '@RG\tID:KPGP-00001\tSM:KPGP-00001\tLB:lib1' /WORK/sibs_lnchen_1/DATA/index/bwa/hg19 KPGP-00001_L1_R1.fq.gz KPGP-00001_L1_R2.fq.gz 1> KPGP-00001_L1.sam 2> KPGP-00001_L1.bwa.align.log
bwa mem -M -t 24 -R '@RG\tID:KPGP-00001\tSM:KPGP-00001\tLB:lib1' /WORK/sibs_lnchen_1/DATA/index/bwa/hg19 KPGP-00001_L2_R1.fq.gz KPGP-00001_L2_R2.fq.gz 1> KPGP-00001_L2.sam 2> KPGP-00001_L2.bwa.align.log
mkdir FASTQ && mv KPGP-00001_L1_R1.fq.gz* KPGP-00001_L2_R1.fq.gz* KPGP-00001_L1_R2.fq.gz* KPGP-00001_L2_R2.fq.gz* FASTQ/
samtools sort -@ 24 -o KPGP-00001_L1.sorted.bam -T temp KPGP-00001_L1.sam
samtools index KPGP-00001_L1.sorted.bam
samtools sort -@ 24 -o KPGP-00001_L2.sorted.bam -T temp KPGP-00001_L2.sam
samtools index KPGP-00001_L2.sorted.bam
mkdir SAM && mv KPGP-00001_L1.sam KPGP-00001_L2.sam SAM/
samtools merge -f -@ 24 KPGP-00001.merge.bam KPGP-00001_L1.sorted.bam KPGP-00001_L2.sorted.bam
mkdir BAM && mv KPGP-00001_L1.sorted.bam KPGP-00001_L2.sorted.bam BAM/
samtools sort -@ 24 -o KPGP-00001.sorted.merge.bam -T temp KPGP-00001.merge.bam
samtools index KPGP-00001.sorted.merge.bam
mv KPGP-00001.merge.bam BAM/
java -Xmx2g -jar /WORK/sibs_lnchen_1/SOFT/picard-2.9.2/picard.jar MarkDuplicates VALIDATION_STRINGENCY=LENIENT CREATE_INDEX=false TMP_DIR=temp TAGGING_POLICY=All REMOVE_DUPLICATES=true INPUT=KPGP-00001.sorted.merge.bam OUTPUT=KPGP-00001.rmdup.bam METRICS_FILE=KPGP-00001.picard.metrics 2> KPGP-00001.picard.log
samtools view -q 1 -h KPGP-00001.rmdup.bam | samtools sort -@ 24 -o KPGP-00001.uniAln.rmdup.bam
samtools index KPGP-00001.uniAln.rmdup.bam
samtools mpileup -ugf /WORK/sibs_lnchen_1/DATA/genome/hg19/hg19.fa KPGP-00001.uniAln.rmdup.bam | bcftools call --threads 1 -vmO z -o KPGP-00001.vcf.gz
tabix -p vcf KPGP-00001.vcf.gz
bcftools filter -O z -s LOWQUAL -i '%QUAL>10' -o KPGP-00001.flt.vcf.gz KPGP-00001.vcf.gz
