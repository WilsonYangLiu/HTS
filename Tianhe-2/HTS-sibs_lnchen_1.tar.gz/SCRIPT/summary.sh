#!/bin/bash

DIR=/HOME/anjiemed_1/WORKSPACE/SH_DATA/TEST/
reference=/HOME/anjiemed_1/WORKSPACE/SH_DATA/genome/hg19/hg19.fa
BAM=KPGP-00001.sorted.merge.bam
VCF=KPGP-00001.flt.vcf.gz

# qualimap options
qualimap=/HOME/sibs_lnchen_1/WORKSPACE/SOFT/qualimap_v2.2.1/qualimap
species=HUMAN
nreads=1000
thread=24
nwindows=4000
format=HTML
MEM=16G

cd $DIR

:<<BLOCK
# Use Qualimap for BAM
$qualimap bamqc -bam $BAM -c -gd $species -nr $nreads -nt $thread -nw $nwindows -outformat $format 1> ${BAM}.qualimap.log
#$qualimap bamqc -bam $BAM -c -gd $species -nr $nreads -nt $thread -nw $nwindows -outformat $format --java-mem-size=$MEM
BLOCK

# Use samtools for BAM
#samtools flagstat $BAM > ${BAM}.flagstat
#samtools depth -a $BAM | gzip > ${BAM}.depth.gz

samtools stats $BAM > ${BAM}.ststs
mkdir ${BAM}_stats && plot-bamstats -p ${BAM}_stats/ ${BAM}.stats

# use bcftools for VCF
bcftools stats -F $reference -s - $VCF > ${VCF}.stats
mkdir ${VCF}_stats && plot-vcfstats -p ${VCF}_stats/ ${VCF}.stats