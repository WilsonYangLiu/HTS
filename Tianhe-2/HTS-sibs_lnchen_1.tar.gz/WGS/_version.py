#!/usr/bin/env python
# -*- coding: utf-8 -*-

############################################################
#  Copyright (c) 2016 Wei-Xin Liu
#  Program: *
#  Author: Wei-Xin Liu (lweixin316@gmail.com)
############################################################

__version__ = '0.1.1'
